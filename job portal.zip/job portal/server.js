// API Documentation 
import swaggerUi from "swagger-ui-express";
import swaggerDoc from "swagger-jsdoc";
// packages imports;
import express from "express";
import "express-async-errors";
import mongoose from "mongoose";
import dotenv from "dotenv";
import cors from "cors";
import morgan from "morgan";
//security packages
import helmet from "helmet";
import xss from "xss-clean";
import mongoSanitize from "express-mongo-sanitize";
//routes imports;
import testRoutes from "./routes/testRoutes.js";
import authRoutes from "./routes/authRoutes.js";
import errorMiddleware from "./middlewares/errorMiddleware.js";
import jobsRoutes from "./routes/jobsRoutes.js";
import userRoutes from "./routes/userRoutes.js";

// dot env config
dotenv.config();

//swagger api config
const options = {
  definition: {
    openapi: "3.0.0",
    info: {
        title: 'job portal Application',
        description: 'NodeJS and ExpressJS job portal Application'
    },
    servers: [
        {
            url: "http://localhost:8080"
        }
    ]
  },
  apis:['./routes/*.js']
};

const spec = swaggerDoc(options);
//rest object
const server = express();
const PORT = process.env.PORT || 8080;


//middlewares
server.use(helmet());
server.use(xss());
server.use(mongoSanitize());
server.use(express.json());
server.use(cors());
server.use(morgan("dev"));
//routes
server.use('/api/v1/test', testRoutes);
server.use("/api/v1/auth", authRoutes);
server.use("/api/v1/user", userRoutes);
server.use("/api/v1/job", jobsRoutes);

// ===home route root
server.use("/api-doc", swaggerUi.serve, swaggerUi.setup(spec));

// validation middleware
server.use(errorMiddleware);

mongoose.connect("mongodb://127.0.0.1:27017/job").then((e) => console.log(`connected to mongodb: ${e.connection.host}`)).catch((e) => console.log(e));

//listen 
server.listen(PORT, () => console.log(`Node server running in ${process.env.DEV_MODE} mode on port no ${PORT}`));