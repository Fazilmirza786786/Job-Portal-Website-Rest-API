import express from 'express';
import userAuth from '../middlewares/authMiddleware.js';
import { createJobController, deleteJobController, getAllJobsController, jobStatsController, updateJobController } from '../controllers/jobsController.js';

const router = express.Router();

//create jobs
router.post('/create-job', userAuth, createJobController);

//get jobs
router.get('/get-job', userAuth, getAllJobsController);

//updates jobs 
router.patch('/update-job/:id', userAuth, updateJobController);

//delete jobs || delete
router.delete("/delete-job/:id", userAuth, deleteJobController);

//Jobs stats filter
router.get("/job-stats", userAuth, jobStatsController)


export default router;