import express from "express";
import {loginController, registerController }  from "../controllers/authControllers.js";
import rateLimit from "express-rate-limit";

//ip limiter
const limiter = rateLimit({
    windows: 15 * 60 * 1000,
    max: 100,
    standardHeaders: true,
    legacyHeaders: false,
});


//router object
const router = express.Router();

//routes

/**
 * @swagger
 * components:
 *  schemas:
 *    User:
 *      type: Object
 *      required:
 *         -name
 *         -lastName
 *         -email
 *         -password
 *         -location
 *      properties:
 *        id:
 *          type: string
 *          description: The Auto-generated id of user collection
 *        name:
 *          type: string
 *          description: User name
 *        lastName:
 *          type: string
 *          descriptiion: User Last Name
 *        email:
 *          type: string
 *          description: user email address
 *        password:
 *          type: string
 *          descriptin: user password should be greater then 6 character
 *        location:
 *          type: string
 *          description: user location city and country
 *      example:
 *         id:gwbwcbwwjn2
 *         name:John
 *         lastName:Doe
 *         email:johndoe@gmail.com
 *         password:test@1234
 *         location:mumbai
 */

/**
 *  @swagger
 *  tags:
 *    name: Auth
 *    description: authentication apic
 */

/**
 *  @swagger
 *  /api/v1/auth/register:
 *     post:
 *       summary: register new user
 *       tags: [Auth]
 *       requestBody:
 *        required: true
 *        content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/User'
 *       responses:
 *        200:
 *          description: user created successfully
 *          content:
 *            application/json:
 *              schema:
 *                $ref: '#/components/schemas/User'
 *        500:
 *          description: internal server error
 */
//routs for register
router.post('/register', limiter, registerController);

//for login
/**
 * @swagger
 * /api/v1/auth/login:
 *  post:
 *    summary: login page
 *    tags: [Auth]
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            $ref: '#/components/schemas/User'
 *    responses:
 *      200:
 *        description: login successfully
 *        content:
 *          application/json:
 *            schema:
 *              $ref: '#/components/schemas/User'
 *      500:
 *       description: something went wrong
 */

//routes for login
router.post("/login", limiter, loginController);


//export 
export default router;